运行方法：
1.安装node.js和anywhere，教程见https://www.jianshu.com/p/3f0b7ea9df53
2.打开cmd，在scatterplot文件夹下执行命令anywhere